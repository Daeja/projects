package com.example.hyunx.voca;

import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class AddActivity extends AppCompatActivity {
    EditText voca, mean;
    SQLiteDatabase db;
    DBHelper helper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.add_view);

        helper = new DBHelper(this);

        try {
            db = helper.getWritableDatabase();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        voca = (EditText) findViewById(R.id.vocaEdit);
        mean = (EditText) findViewById(R.id.meanEdit);
    }

    public void add(View target) {
        String str_voca = voca.getText().toString();
        String str_mean = mean.getText().toString();

        try {
            db.execSQL("INSERT INTO voca VALUES (null, '" + str_voca + "', '" + str_mean + "' );");
            Toast.makeText(getApplicationContext(), "추가 완료", Toast.LENGTH_SHORT).show();
        } catch (SQLException e) {
            e.printStackTrace();
            Toast.makeText(getApplicationContext(), "추가 실패", Toast.LENGTH_SHORT).show();
        }

        voca.setText("");
        mean.setText("");
    }
}
