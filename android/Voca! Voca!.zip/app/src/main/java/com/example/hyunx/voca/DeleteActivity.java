package com.example.hyunx.voca;

import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class DeleteActivity extends AppCompatActivity {
    EditText voca, mean;
    SQLiteDatabase db;
    DBHelper helper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.delete_view);

        helper = new DBHelper(this);

        try {
            db = helper.getWritableDatabase();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        voca = (EditText) findViewById(R.id.vocaEdit);
        mean = (EditText) findViewById(R.id.meanEdit);
    }

    public void deleteSearch(View target) {
        Cursor cur;
        String str_voca = voca.getText().toString();

        if (str_voca == null) {
            Toast.makeText(getApplicationContext(), "단어를 먼저 입력하세요.", Toast.LENGTH_SHORT).show();
        } else {
            cur = db.rawQuery("SELECT vocabulary, mean FROM voca WHERE vocabulary = '" + str_voca + "';", null);

            while (cur.moveToNext()) {
                String str_mean = cur.getString(1);
                mean.setText(str_mean);
            }
        }
    }

    public void delete(View target) {
        String str_voca = voca.getText().toString();

        if (str_voca == null) {
            Toast.makeText(getApplicationContext(), "단어를 먼저 입력하세요.", Toast.LENGTH_SHORT).show();
        } else {
            try {
                db.execSQL("DELETE FROM voca WHERE vocabulary = '" + str_voca + "';");
                Toast.makeText(getApplicationContext(), "삭제 완료", Toast.LENGTH_SHORT).show();
            } catch (SQLException e) {
                e.printStackTrace();
                Toast.makeText(getApplicationContext(), "삭제 실패", Toast.LENGTH_SHORT).show();
            }
        }

        voca.setText("");
        mean.setText("");
    }
}
