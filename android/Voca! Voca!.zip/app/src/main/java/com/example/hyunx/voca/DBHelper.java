package com.example.hyunx.voca;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * Created by pc1 on 2017-06-12.
 */

public class DBHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "voca.db";
    private static final int DATABASE_VERSION = 2;

    public DBHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE voca ( _id integer PRIMARY KEY AUTOINCREMENT, vocabulary TEXT, mean TEXT);");
    }

    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS voca");
        onCreate(db);
    }
}
