package com.example.hyunx.voca;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

public class MainActivity extends AppCompatActivity {
    Toolbar toolbar;
    Button prevBtn, nextBtn;
    TextView eng, kor;
    TextView page;

    SQLiteDatabase db;
    DBHelper helper;

    private final long FINISH_INTERVAL_TIME = 2000;
    private long backPressedTime = 0;

    private int count_raw = 0;
    private int currentNum = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main_view);

        toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        helper = new DBHelper(this);

        try {
            db = helper.getWritableDatabase();
            Toast.makeText(getApplicationContext(), "DB 초기화 완료", Toast.LENGTH_SHORT).show();
        } catch (SQLiteException ex) {
            db = helper.getReadableDatabase();
            Toast.makeText(getApplicationContext(), "DB 초기화 실패", Toast.LENGTH_SHORT).show();
        }

        prevBtn = (Button) findViewById(R.id.previous);
        nextBtn = (Button) findViewById(R.id.next);

        eng = (TextView) findViewById(R.id.eng_text);
        kor = (TextView) findViewById(R.id.kor_text);
        page = (TextView) findViewById(R.id.pages);
    }

    //툴바에 메뉴 넣기
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu, menu);
        return true;
    }

    //툴바 버튼 이벤트
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        //각각의 버튼을 클릭할때의 수행할것을 정의해 준다.
        switch (item.getItemId()) {
            case R.id.addBtn:
                addVoca();
                Toast.makeText(this, "단어 추가 버튼을 눌렀습니다.", Toast.LENGTH_SHORT).show();
                break;
            case R.id.deleteBtn:
                deleteVoca();
                Toast.makeText(this, "단어 삭제 버튼을 눌렀습니다.", Toast.LENGTH_SHORT).show();
                break;
        }

        return true;
    }

    public void addVoca() {
        Intent intent = new Intent(getApplicationContext(), AddActivity.class);
        startActivity(intent);
    }

    public void deleteVoca() {
        Intent intent = new Intent(getApplicationContext(), DeleteActivity.class);
        startActivity(intent);
    }

    public void onClickedPrevious(View target) {
        Cursor cursor;

        cursor = db.rawQuery("SELECT count(*) from voca", null);

        while (cursor.moveToNext()) {
            count_raw = cursor.getInt(0);
        }

        if(count_raw == 0) {
            Toast.makeText(this, "등록된 단어가 없습니다.", Toast.LENGTH_SHORT).show();
        }

        if (currentNum <= 1) {
            currentNum = count_raw;
        } else {
            currentNum--;
        }

        search();
    }

    public void onClickedNext(View target) {
        Cursor cursor;

        cursor = db.rawQuery("SELECT count(*) from voca", null);

        while (cursor.moveToNext()) {
            count_raw = cursor.getInt(0);
        }

        if(count_raw == 0) {
            Toast.makeText(this, "등록된 단어가 없습니다.", Toast.LENGTH_SHORT).show();
        }

        if (currentNum >= count_raw) {
            currentNum = 1;
        } else {
            currentNum++;
        }

        search();
    }

    public void search() {
        Cursor cur;

        cur = db.rawQuery("SELECT vocabulary, mean FROM voca WHERE _id = " + currentNum + ";", null);

        while (cur.moveToNext()) {
            String voca = cur.getString(0);
            eng.setText(voca);

            String mean = cur.getString(1);
            kor.setText(mean);
        }

        page.setText(currentNum + " / " + count_raw);
    }

    //취소키 구현
    @Override
    public void onBackPressed() {
        long tempTime = System.currentTimeMillis();
        long intervalTime = tempTime - backPressedTime;

        if (0 <= intervalTime && FINISH_INTERVAL_TIME >= intervalTime) {
            super.onBackPressed();
        } else {
            backPressedTime = tempTime;
            Toast.makeText(getApplicationContext(), "한번 더 입력시 앱이 종료됩니다.", Toast.LENGTH_SHORT).show();
        }
    }
}
